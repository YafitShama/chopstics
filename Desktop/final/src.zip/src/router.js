import HomePage from "./components/HomePage";
import ChopsticsCart  from "./components/Cart";
import Contact from "./components/Contact";
import Order from "./components/Order";
import { createBrowserRouter } from "react-router-dom";
import Layout from "./components/Layout";
import AboutUs from "./components/AboutUs";
import Product from "./components/Product";
import ChopsticsList from "./components/ChopsticsList";
import PayNow from "./components/PayNow";
import Login from "./components/Login";
import Register from "./components/Register";
import User from "./components/User";



const router = createBrowserRouter([
    {   element: <Layout/>,
        children: [
        {
            path: "/",
            element: <HomePage/>,
        },
        {
            path: "/chopsticsCart",
            element: <ChopsticsCart/>,
        },
        {
            path: "/Contact",
            element: <Contact/>,
        },
        {
            path: "/ChopsticsCart",
            element: <ChopsticsCart/>,
        },
        {
            path: "/Order",
            element: <Order/>,
       },  
       {
        path: "/Login",
        element: <Login/>,
    },
    {
        path: "/User",
        element: <User/>,
    },
    {
        path: "/Register",
        element: <Register/>,
   },  
        {
        path: "/PayNow",
        element: <PayNow/>,
   },
       {
        path: "/AboutUs",
        element: <AboutUs/>,
        },
        {
            path: "/ChopsticsList",
            children: [
                {
                    index: true,
                    element: <ChopsticsList />,
                },
                {
                    path: ":name",
                    element: <Product />,
                },
            ]
        },
    ]
},]);

export default router
 