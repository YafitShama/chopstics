// // import React from 'react';
// // import { AppBar, Toolbar, Typography, IconButton, useMediaQuery, useTheme } from '@mui/material';
// // import MenuIcon from '@mui/icons-material/Menu';


// // const ResponsiveAppBar = ({ title, navigation, ...props }) => {
// //   const theme = useTheme();
// //   const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

// //   // Handle navigation logic here (e.g., using MUI's `useRoutes` or `useLink` hooks)

// //   return (
// //     <AppBar position="static" sx={{ backgroundColor: '#000' }}>
// //       <Toolbar>
// //         <Typography variant="h6" component="h1" sx={{ flexGrow: 1 }}>
// //           {title}
// //         </Typography>
// //         {isMobile ? (
// //           <IconButton onClick={() => /* Handle mobile menu toggle */}>
// //             <MenuIcon />
// //           </IconButton>
// //         ) : (
// //           <NavigationLinks navigation={navigation} /> // Replace with your navigation rendering
// //         )}
// //       </Toolbar>
// //     </AppBar>
// //   );
// // };

// // const NavigationLinks = ({ navigation }) => {
// //   // Render navigation links here (e.g., using MUI's `NavLink` or `Link` components)
// //   return (
// //     <div>
// //       {/* Your navigation link rendering logic */}
// //     </div>
// //   );
// // };

// // export default ResponsiveAppBar;



// import React from 'react';
// import { AppBar, Toolbar, Typography, IconButton, useMediaQuery, useTheme } from '@mui/material';
// import MenuIcon from '@mui/icons-material/Menu';
// import router from '../router';

// const ResponsiveAppBar = ({ title, navigation, ...props }) => {
//   const theme = useTheme();
//   const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

//   // Handle navigation logic here (e.g., using MUI's `useRoutes` or `useLink` hooks)

//   return (
//     <AppBar position="static" sx={{ backgroundColor: '#000' }}>
//       <Toolbar>
//         <Typography variant="h6" component="h1" sx={{ flexGrow: 1 }}>
//           {title}
//         </Typography>
//         {isMobile ? (
//           <IconButton onClick={() => /* Handle mobile menu toggle */}>
//             <MenuIcon />
//           </IconButton>
//         ) : (
//           <NavigationLinks navigation={router} /> 
//         )}
//       </Toolbar>
//     </AppBar>
//   );
// };

// const NavigationLinks = ({ navigation }) => {
//   // Render navigation links here (e.g., using MUI's `NavLink` or `Link` components)
//   return (
//     <div>
//       {/* Your navigation link rendering logic */}
//       {navigation.map((navItem) => (
//         <Link key={navItem.name} to={navItem.path}>
//           {navItem.name}
//         </Link>
//       ))}
//     </div>
//   );
// };

// export default ResponsiveAppBar;





import React, { useState } from 'react';
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  useMediaQuery,
  useTheme,
  Drawer,
  Divider,
  List,
  ListItem,
  ListItemText,
  Link,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';

const ResponsiveAppBar = ({ title, navigation, ...props }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  const [drawerOpen, setDrawerOpen] = useState(false); // מצב פתיחת המגירה

  const handleDrawerOpen = () => {
    setDrawerOpen(true);
  };

  const handleDrawerClose = () => {
    setDrawerOpen(false);
  };

  return (
    <div>
      <AppBar position="static" sx={{ backgroundColor: '#000' }}>
        <Toolbar>
          <Typography variant="h6" component="h1" sx={{ flexGrow: 1 }}>
            {title}
          </Typography>
          {isMobile ? (
            <IconButton onClick={handleDrawerOpen}>
              <MenuIcon />
            </IconButton>
          ) : (
            <NavigationLinks navigation={navigation} />
          )}
        </Toolbar>
      </AppBar>

      {/* מגירה ניידת */}
      <Drawer
        anchor="right"
        open={drawerOpen}
        onClose={handleDrawerClose}
        sx={{
          width: '250px',
          flexShrink: 0,
        }}
      >
        <Divider />
        <List>
          {navigation.map((navItem) => (
            <ListItem key={navItem.name}>
              <Link to={navItem.path} underline="none" onClick={handleDrawerClose}>
                <ListItemText primary={navItem.name} />
              </Link>
            </ListItem>
          ))}
        </List>
      </Drawer>
    </div>
  );
};

const NavigationLinks = ({ navigation }) => {
  return (
    <div>
      {navigation.map((navItem) => (
        <Link key={navItem.name} to={navItem.path} sx={{ margin: '10px' }}>
          {navItem.name}
        </Link>
      ))}
    </div>
  );
};

export default ResponsiveAppBar;
