import React, { useState, useEffect } from 'react';
import { getAllProducts } from '../services/products';
import { Link } from 'react-router-dom';
import { Card, CardActionArea, CardMedia, CardContent, CardActions, Typography, Button } from '@mui/material';
import './ProductCollage.css'; // Import your custom CSS (optional)
import ProductCollage from 'src/styles/ProductCollage';

const ProductCollage = () => {
    const [productList, setProductList] = useState([]);
  
    useEffect(() => {
      const fetchData = async () => {
        try {
          const allProducts = await getAllProducts();
          setProductList(allProducts);
        } catch (error) {
          console.error(error.message);
        }
      };
  
      fetchData();
    }, []);
  
    return (
      <div className="product-collage">
        {productList.map((product) => (
          <Card key={product.name} sx={{ maxWidth: 345 }}>
            <CardActionArea>
              <CardMedia
                component="img"
                image={product.img}
                alt={product.name}
              />
              <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                  {product.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {product.price} ש"ח
                </Typography>
              </CardContent>
            </CardActionArea>
            <CardActions>
              <Link to={`/${product.name}`}>
                <Button size="small" color="primary">
                  View Details
                </Button>
              </Link>
            </CardActions>
          </Card>
        ))}
      </div>
    );
  };
  
  export default ProductCollage;
  