import { purple, red } from '@mui/material/colors';
import React from 'react'

const primary = deepOrange[500]; // #ff5722
// const accent = purple['800']; // #d84315
// const accent = purple.A200; // #e040fb (alternative method)
const ColorPalette = () => {
    
  return (
    <div>
      
    </div>
  )
}

export default ColorPalette


