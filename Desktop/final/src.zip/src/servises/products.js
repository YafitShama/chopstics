import axios from "axios"
import { apiClient } from "../Api/apiClient";

const getAllProducts = async() => {
    try {
        const res = await apiClient.get('Products'); // Adjust the endpoint as needed
        return res.data; // Assuming the server response contains the products directly
    } catch (error) {
        throw error; // Rethrow the error for handling in the calling component
    }     
}

export {getAllProducts}