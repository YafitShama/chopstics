import { apiClient } from "../Api/apiClient";

export const loginUser = async (credentials) => {
  try {
    const res = await apiClient.post("Users/login", credentials);
    return res.data;
  } catch (error) {
    throw error;
  }
};

export const signUpUser = async (newUser) => {
  try {
    const res = await apiClient.post("Users", newUser);
    return res.data;
  } catch (error) {
    throw error;
  }
};

export const updateUser = async (user) => {
  try {
    const res = await apiClient.put(`Users/${user.id}`, user);
    return res.data;
  } catch (error) {
    throw error;
  }
};


export const getUserById = async (userId) => {
  try {
    const res = await apiClient.get(`Users/${userId}`);
    return res.data;
  } catch (error) {
    throw error;
  }
};
