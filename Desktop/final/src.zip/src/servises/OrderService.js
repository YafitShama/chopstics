import { apiClient } from "../Api/apiClient";

// Function to post a new order
export const postOrder = async (orderData) => {
  try {
    const res = await apiClient.post("Order", orderData);
    return res.data;
  } catch (error) {
    throw error;
  }
};

// Function to get orders by user ID
export const getOrdersByUserId = async (userId) => {
  try {
    const res = await apiClient.get(`Order/user/${userId}`);
    return res.data;
  } catch (error) {
    throw error;
  }
};

// Function to delete an order by ID
export const deleteOrder = async (orderId) => {
  try {
    const res = await apiClient.delete(`Order/${orderId}`);
    return res.data; // You can return the response if needed
  } catch (error) {
    throw error;
  }
};
