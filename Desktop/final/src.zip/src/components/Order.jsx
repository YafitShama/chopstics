import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Checkbox from '@mui/material/Checkbox';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormLabel from '@mui/material/FormLabel';
import Grid from '@mui/material/Grid';
import OutlinedInput from '@mui/material/OutlinedInput';
import { styled } from '@mui/system';
import { PaymentOutlined } from '@mui/icons-material';
import { Button } from '@mui/material';
import './General.css';

const Order = () => {
  const navigate = useNavigate();
  const location = useLocation(); // Get location to retrieve state
  const totalAmount = location.state?.totalAmount || 0; // Retrieve total amount

  // Form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [address1, setAddress1] = useState('');
  const [address2, setAddress2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('');
  const [selectedOption, setSelectedOption] = useState('₪איסוף עצמי ללא עלות 0');

  const sends = [
    { label: '₪איסוף עצמי ללא עלות 0', cost: 0 },
    { label: 'משלוח עד הבית בתוך העיר בעלות ₪20', cost: 20 },
    { label: 'מחוץ לעיר בעלות ₪120  משלוח אקספרס', cost: 120 },
  ];

  // Handle option change
  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  // Handle order creation and navigate to payment
  const handlePayment = async () => {
    // Gather the form data (nullable)
    const orderData = {
      firstName: firstName || null,
      lastName: lastName || null,
      address1: address1 || null,
      address2: address2 || null,
      city: city || null,
      state: state || null,
      zip: zip || null,
      country: country || null,
      selectedOption,
    };

    alert("ההזמנה התקבלה בהצלחה!"); // Optional success message
    navigate('/PayNow', { state: { totalAmount: totalAmount } }); // Pass total amount to PayNow
  };

  const FormGrid = styled(Grid)(() => ({
    display: 'flex',
    flexDirection: 'column',
  }));

  return (
    <>
      <video autoPlay loop muted className="cart-video">
        <source src="/assets/vid2.mp4" type="video/mp4" />
      </video>
      <br />
      <Grid container spacing={3} sx={{ my: 4, backgroundColor: 'rgba(255, 238, 232, 0.5)', direction: 'rtl' }}>
        <FormGrid item xs={12} md={6}>
          <FormLabel htmlFor="first-name">First name</FormLabel>
          <OutlinedInput
            id="first-name"
            name="first-name"
            type="text"
            placeholder="ישראל"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={12} md={6}>
          <FormLabel htmlFor="last-name">Last name</FormLabel>
          <OutlinedInput
            id="last-name"
            name="last-name"
            type="text"
            placeholder="ישראלי"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={12}>
          <FormLabel htmlFor="address1">Address line 1</FormLabel>
          <OutlinedInput
            id="address1"
            name="address1"
            type="text"
            placeholder="שם רחוב ומספר"
            value={address1}
            onChange={(e) => setAddress1(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={12}>
          <FormLabel htmlFor="address2">Address line 2</FormLabel>
          <OutlinedInput
            id="address2"
            name="address2"
            type="text"
            placeholder="Apartment, suite, unit, etc. (אופציונלי)"
            value={address2}
            onChange={(e) => setAddress2(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={6}>
          <FormLabel htmlFor="city">City</FormLabel>
          <OutlinedInput
            id="city"
            name="city"
            type="text"
            placeholder="ירושלים"
            value={city}
            onChange={(e) => setCity(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={6}>
          <FormLabel htmlFor="state">State</FormLabel>
          <OutlinedInput
            id="state"
            name="state"
            type="text"
            placeholder="ישראל"
            value={state}
            onChange={(e) => setState(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={6}>
          <FormLabel htmlFor="zip">Zip / Postal code</FormLabel>
          <OutlinedInput
            id="zip"
            name="zip"
            type="text"
            placeholder="12345"
            value={zip}
            onChange={(e) => setZip(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={6}>
          <FormLabel htmlFor="country">Country</FormLabel>
          <OutlinedInput
            id="country"
            name="country"
            type="text"
            placeholder="ישראל"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
          />
        </FormGrid>
        <FormGrid item xs={12}>
          <FormControlLabel
            control={<Checkbox name="saveAddress" value="yes" />}
            label="Use this address for payment details"
          />
          <div>
            <Button 
              variant="contained" 
              endIcon={<PaymentOutlined />}
              onClick={handlePayment}
              style={{ backgroundColor: '#ff5722', color: 'white' }}
            >
              מעבר לתשלום
            </Button>
          </div>
        </FormGrid>
      </Grid>

      <div>
        <label>בחר את אופן המשלוח:</label>
        <select onChange={handleOptionChange} value={selectedOption}>
          {sends.map((send) => (
            <option key={send.label} value={send.label}>
              {send.label}
            </option>
          ))}
        </select>
      </div>
      <br />
    </>
  );
};

export default Order;
