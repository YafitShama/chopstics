import React from 'react';
import { useEffect, useState } from 'react';

import {  Grid, Card, CardContent, CardMedia, Typography } from '@mui/material';
import { Link } from 'react-router-dom';
import './General.css';
import { getAllProducts } from '../servises/products';

const ChopsticksList = () => {
  const [productList, setProductList] = useState([]);

  const fetchData = async () => {
    try {
      const allProducts = await getAllProducts();
      setProductList(allProducts);
    } catch (error) {
      console.error(error.message);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <Grid container spacing={2}className="beginning-page-padding">
      {productList.map((product) => (
        <Grid item xs={12} md={4} key={product.name}>
          <Card>
            <CardMedia
              component="img"
              image={product.img} 
              alt={product.name}
              height={200}
            />
            <CardContent>
              <Typography variant="h5" component="div">
                <Link to={product.name}
                   style={{
                    textDecoration: 'none',
                    color: '##ff5722',
                    fontWeight: 'bold'
                   }}                
                >{product.name}</Link>
              </Typography>
            </CardContent>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default ChopsticksList;
