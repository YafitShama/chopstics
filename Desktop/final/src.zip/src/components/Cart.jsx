import React, { useContext } from 'react';
import { CartContext } from './CartContext';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Typography,
  Card,
  CardHeader,
  CardContent,
  CardActions,
  Button,
  Grid,
  ListItem,
  ListItemText,
  IconButton,
  Avatar,
} from '@mui/material';
import DeleteIcon from '@mui/icons-material/Delete';
import ShoppingCartCheckoutIcon from '@mui/icons-material/ShoppingCartCheckout';
import './General.css';
import { ShoppingCart } from '@mui/icons-material';

const Cart = () => {
  const { cartItems, removeFromCart, calculateTotal } = useContext(CartContext);
  const navigate = useNavigate();

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
      <video autoPlay loop muted className="cart-video">
        <source src="/assets/vid2.mp4" type="video/mp4" />
      </video>
      <Card sx={{ width: '80%', maxWidth: 600, backgroundColor: 'rgba(255, 238, 232, 0.7)'}}>
        <CardHeader title="ההזמנה שלך" />
        {cartItems.length === 0 ? (
          <CardContent sx={{ textAlign: 'center' }}>
            <ShoppingCart edge="end"/>
            <Typography variant="body1">העגלה עדיין ריקה</Typography>
            
          </CardContent>
        ) : (
          <CardContent>
            <Grid container spacing={2}>
              {cartItems.map((item) => (
                <Grid item xs={12} key={item.product.id}>
                  <ListItem secondaryAction={
                    <IconButton edge="end" aria-label="delete" onClick={() => removeFromCart(item)}>
                      <DeleteIcon />
                    </IconButton>
                  }>
                    <Avatar
                      variant="square"
                      alt={item.product.name}
                      src={item.product.img} 
                      sx={{ width: 56, height: 56, mr: 2 }}
                    />
                    <ListItemText
                      primary={item.product.name}
                      secondary={`${item.quantity} x ₪${item.product.price} = ₪${item.product.price * item.quantity}`}
                    />
                  </ListItem>
                </Grid>
              ))}
            </Grid>
          </CardContent>
        )}
        {cartItems.length > 0 && (
          <CardActions sx={{ display: 'flex', justifyContent: 'space-between' }}>
          <Typography variant="h6">סך ההזמנה: ₪{calculateTotal()}</Typography>
          <Button
            variant="contained"
            endIcon={<ShoppingCartCheckoutIcon />}
            onClick={() => navigate('/Order', { state: { totalAmount: calculateTotal() } })} // Pass total amount
            style={{ backgroundColor: '#ff5722', color: 'black' }}
          >
            שלם עכשיו
          </Button>
        </CardActions>
        )}
      </Card>
    </Box>
  );
};

export default Cart;
