
import React, { useState } from 'react';
import { TextField, Button, Typography, Paper, Container, Grid } from '@mui/material';
import { signUpUser } from '../servises/UserService';
import { Navigate } from 'react-router-dom';

function Register() {
  const [username, setUsername] = useState('');
  const [passwordHash, setPasswordHash] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleRegister = async (e) => {
    e.preventDefault();

    // Create a new user object
    const newUser = {
      username,
      passwordHash,
      email,
    };

    try {
      const response = await signUpUser(newUser);
      console.log('User registered:', response);
      Navigate('/Login'); 
    } catch (err) {
      setError('Registration failed');
      console.error(err);
    }
  };
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        minHeight: '100vh',
        position: 'relative',
        overflow: 'hidden',
      }}
    >
      <video
        autoPlay
        loop
        muted
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          zIndex: -1,
        }}
      >
        <source src="/assets/vid7.mp4" type="video/mp4" />
      </video>
      <Container>
        <Grid container justifyContent="center" alignItems="center">
          <Grid item xs={12} sm={8} md={6}>
            <Paper
              elevation={3}
              sx={{
                padding: 4,
                maxWidth: 400,
                backgroundColor: 'rgba(255, 238, 232, 0.7)',
                borderRadius: 2,
                boxShadow: 3,
              }}
            >
              <Typography variant="h4" gutterBottom align="center">
                Register
              </Typography>
              <form onSubmit={handleRegister} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <TextField
                  label="Username"
                  variant="outlined"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  fullWidth
                />
                <TextField
                  label="Email"
                  variant="outlined"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  fullWidth
                />
                <TextField
                  label="Password"
                  variant="outlined"
                  type="password"
                  value={passwordHash}
                  onChange={(e) => setPasswordHash(e.target.value)}
                  required
                  fullWidth
                />
                <Button
                  type="submit"
                  variant="contained"
                  sx={{
                    backgroundColor: '#ff5722',
                    color: 'black',
                    '&:hover': {
                      backgroundColor: '#e64a19',
                    },
                  }}
                  fullWidth
                >
                  Sign Up
                </Button>
              </form>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}

export default Register;
