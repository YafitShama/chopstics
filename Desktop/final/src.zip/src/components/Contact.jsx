import React from 'react';
import { TextField, Button, Typography, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import { Phone as PhoneIcon, Email as EmailIcon, Place as PlaceIcon, Instagram } from '@mui/icons-material';
import { styled } from '@mui/material/styles';
import './General.css';

// Styled components
const ContactContainer = styled('div')({
  display: 'flex',
  width: '100%',
});

const FormContainer = styled('div')(({ theme }) => ({
  flex: 1,
  padding: theme.spacing(2),
  backgroundColor: 'rgba(255, 238, 232, 0.7)',
  direction: 'rtl',
}));

const StoreDetailsContainer = styled('div')(({ theme }) => ({
  flex: 1,
  padding: theme.spacing(2),
  backgroundColor: 'rgba(255, 238, 232, 0.7)',
}));

const Form = styled('form')(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  gap: theme.spacing(2),
}));

const StyledListItem = styled(ListItem)(({ theme }) => ({
  marginBottom: theme.spacing(1),
}));

const ListItemIconStyled = styled(ListItemIcon)(({ theme }) => ({
  marginRight: theme.spacing(1),
}));

const Contact = () => {
  return (
    <ContactContainer>
      <FormContainer>
        <video autoPlay loop muted className="cart-video">
          <source src="/assets/vid4.mp4" type="video/mp4" />
        </video>
        <Typography variant="h2">רוצים לכתוב לנו?</Typography>
        <Form>
          <TextField
            label="שם מלא"
            variant="outlined"
            required
            fullWidth
          />
          <TextField
            label="כתובת מייל"
            variant="outlined"
            type="email"
            required
            fullWidth
          />
          <TextField
            label="הודעה"
            variant="outlined"
            multiline
            rows={5}
            required
            fullWidth
          />
          <Button variant="contained" type="submit" style={{ backgroundColor: '#ff5722', color: 'white' }}>
            שלח הודעה
          </Button>
        </Form>
      </FormContainer>
      <StoreDetailsContainer>
        <Typography variant="h2">chopstics</Typography>
        <List>
          <StyledListItem>
            <ListItemIconStyled>
              <PhoneIcon />
            </ListItemIconStyled>
            <ListItemText primary="Phone:" secondary="+972 (53) 53-02367" />
          </StyledListItem>
          <StyledListItem>
            <ListItemIconStyled>
              <EmailIcon />
            </ListItemIconStyled>
            <ListItemText primary="Email:" secondary="chopstics@gnail.com" />
          </StyledListItem>
          <StyledListItem>
            <ListItemIconStyled>
              <PlaceIcon />
            </ListItemIconStyled>
            <ListItemText
              primary="Address:"
              secondary="רחוב תלמוד בבלי 12 בית שמש, ישראל" />
          </StyledListItem>
          <StyledListItem>
            <ListItemIconStyled>
              <Instagram />
            </ListItemIconStyled>
            <ListItemText primary="Instagram:" secondary="_yafitshama" />
          </StyledListItem>
        </List>
      </StoreDetailsContainer>
    </ContactContainer>
  );
};

export default Contact;
