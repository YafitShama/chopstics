import React, { useState, useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { Toolbar, styled, IconButton, Menu, MenuItem, Container, Button } from '@mui/material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

const StyledToolbar = styled(Toolbar)`
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: black; /* Dark background for better contrast */
  color: #fff; /* White text for readability */
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
  padding: 0 2rem; /* Padding for better spacing */
`;

const StyledNavLink = styled(NavLink)`
  text-decoration: none;
  color: #ff5722;
  font-weight: bold;
  margin: 0 1rem;
  font-size: 16px;

  &.active {
    color: #ffcebf; /* Light color for active link */
  }
`;

const StyledLogoContainer = styled('div')`
  display: flex;
  align-items: center;
`;

const StyledLogoImage = styled('img')`
  width: 120px; /* Adjust the width as needed */
  margin-right: 1rem;
`;

const Layout = () => {
  const [username, setUsername] = useState(null); // Simulate login state
  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (user) {
      setUsername(user.username); // Set username if logged in
    }
  }, []);

  // Handle user icon click to navigate
  const handleUserIconClick = () => {
    if (username) {
      navigate('/User'); // Navigate to user page if logged in
    } else {
      navigate('/login'); // Navigate to login page if not logged in
    }
  };

  // Handle sign out
  const handleSignOut = () => {
    localStorage.removeItem('user'); // Clear user from local storage
    setUsername(null); // Clear username from state
  };

  const logoPath = '/assets/logo.png'; // Path to your logo image

  return (
    <div>
      <StyledToolbar>
        <Container maxWidth="lg" disableGutters>
          <StyledLogoContainer>
            <StyledLogoImage src={logoPath} alt="Logo" />
            <div>
              <StyledNavLink to="/Contact">Contact Us</StyledNavLink>
              <StyledNavLink to="/AboutUs">About Us</StyledNavLink>
              <StyledNavLink to="/ChopsticsCart">Cart</StyledNavLink>
              <StyledNavLink to="/ChopsticsList">Orders</StyledNavLink>
              <StyledNavLink to="/">Home</StyledNavLink>
            </div>
          </StyledLogoContainer>

          {/* User Icon / Greeting */}
          <div>
            <IconButton onClick={handleUserIconClick} color="inherit">
              <AccountCircleIcon sx={{ color: username ? 'rgba(255, 238, 232, 0.7)' : '#ff5722' }} />
            </IconButton>
            {username && (
              <>
                <span style={{ color: '#ffcebf', marginLeft: '0.5rem' }}>Hello, {username}</span>
                <Button 
                  onClick={handleSignOut} 
                  color="inherit" 
                  sx={{ marginLeft: '1rem', color: '#ffcebf' }}>
                  Sign Out
                </Button>
              </>
            )}
          </div>
        </Container>
      </StyledToolbar>
      <Outlet />
    </div>
  );
};

export default Layout;
