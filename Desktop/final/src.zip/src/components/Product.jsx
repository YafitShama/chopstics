import React, { useState, useEffect, useContext } from 'react';
import { getAllProducts } from '../servises/products';
import { CartContext } from './CartContext';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Typography,
  Card,
  CardContent,
  CardMedia,
  Button,
  Stack,
  TextField,
  Snackbar,
  Alert,
  Grid
} from '@mui/material';
import './General.css';



const Product = () => {
  const { name } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState();
  const [quantity, setQuantity] = useState(1); //  הוספת כמות
  const { addToCart } = useContext(CartContext);
  const [openSnackbar, setOpenSnackbar] = useState(false);

   

  const fetchData = async () => {
    try {
      const productList = await getAllProducts();
      const foundProduct = productList?.find((p) => p.name === name);

      foundProduct ? setProduct(foundProduct) : navigate('/');
    } catch (error) {
      console.log(error.message);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    setOpenSnackbar(true); // פתח את ה-Snackbar
  }


  return (
      <div>
         <video autoPlay loop muted className="cart-video">
      <source src="/assets/vid3.mp4" type="video/mp4" />
    </video>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <Card>
              <CardMedia
                component="img"
                image={product?.img} 
                alt={product?.name}
                height={400} 
              />
            </Card>
          </Grid>
          <Grid item xs={12} md={6}>
            <Card style={{backgroundColor: 'rgba(255, 238, 232, 0.7)'}}>
              <CardContent style={{direction: 'rtl'}}>
                <Typography variant="h5" component="div">
                  {product?.name}
                </Typography>
                <Typography variant="body1">
                  מחיר: {product?.price} ש"ח
                </Typography>
                <Typography variant="body2" >
                   {product?.description}
                </Typography>
              </CardContent>
              <Stack spacing={2}>
                <TextField
                  id="quantity"
                  label="כמות"
                  type="number"
                  value={quantity}
                  min={1}
                  max={10}
                  onChange={(event) => setQuantity(parseInt(event.target.value))}
                />
                <Button variant="contained" 
                style={{ backgroundColor: '#ff5722', color: 'black' }}
                 onClick={handleAddToCart}>
                  הוספה לסל
                </Button>
                <Button variant="contained" 
                style={{ backgroundColor: '#ff5722', color: 'black' }}
                 onClick={()=>navigate('../')}>
                  חזרה לכל המוצרים
                </Button>
                <Button variant="contained"
                style={{ backgroundColor: '#ff5722', color: 'black' }}
                onClick={()=>navigate('/ChopsticsCart')}>
                לעגלה
                </Button>
              </Stack>
            </Card>
          </Grid>
        </Grid>
             <Snackbar
             open={openSnackbar}
             autoHideDuration={5000} 
             onClose={() => setOpenSnackbar(false)}
             anchorOrigin={{ vertical: 'top', horizontal: 'center' }}

           >
             <Alert severity="success" style={{ backgroundColor: '#ff5722', color: 'black' }}
            >המוצר נוסף לעגלה בהצלחה</Alert>
           </Snackbar>
        
     
       
      </div>
    );
  }
    
  

export default Product;


