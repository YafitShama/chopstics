import React from 'react';
import './HomePage.css'; 
import './General.css';
import {Typography, Button, Box} from '@mui/material';
import { useNavigate } from 'react-router-dom';
const HomePage = () => {
const navigate = useNavigate();

return (
<>

  <Box className="homePageContainer" 
         sx={{
          my: 4,
          backgroundColor: 'rgba(255, 238, 232, 0.5)',
        }}>
    <Box className="textContainer">
      <Typography className="title" variant="h2" >ברוכים הבאים למקום שכולו chopstics</Typography>
      <Typography className="description" variant="body1">
                   תפריט אסייתי  יפני-סיני עם השפעות ממטבחים נוספים מהמזרח הרחוק. <br/>
           יותר מ-80 מנות שעושות כבוד למקור,
           <br/> מחומרי הגלם היקרים והאיכותיים ביותר בייבוא מיוחד
           ובהכנה במקום<br/>
           מהנודלס ועד הרטבים המיוחדים. וכן, הכול טרי. תמיד. <br/>
           רשת ג'ופסטיקס מתמחה בנפלאות המטבח האסייתי על כל סוגיו,
            ובפרט בכל הקשור לעולם הסושי.<br/>
             העקרונות המנחים אותנו הם שילוב של חומרי גלם טריים ואיכותיים לצד מחירים נוחים ותודעת שירות גבוהה,<br/>
              והם אלה המזמינים את קהל הלקוחות לשוב וליהנות בכל פעם מחדש, הן במסעדות הרשת והן במשלוחים.
    
      </Typography>
      <div className="buttonContainer">
    <Button variant="outlined" onClick={() => navigate('/AboutUs')} 
    style={{
      color: '#000', 
      border: '2px solid #ff5722', 
    }}>
        קרא עוד
    </Button>
</div>

    </Box>
  </Box>
  <div className="centeredStackContainer">
  <Button
  variant="contained"
  onClick={() => navigate('/ChopsticsList')}
  
  sx={{
    fontSize: '1.25rem',
    padding: '1rem 2rem',
    fontWeight: 'bold',
    backgroundColor: '#ff5722',
    color: 'black',
    '&:hover': {
      backgroundColor: '#e64a19',
    },
  }}
>
  להזמנה
</Button>

    
   
</div>

  <video autoPlay loop muted className="cart-video">
        <source src="/assets/vid6.mp4" type="video/mp4" />
      </video>
  </>
);
};
export default HomePage