import React, { useState } from 'react';
import { Button, Grid, Typography } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import { useNavigate, useLocation } from 'react-router-dom';
import { postOrder } from '../servises/OrderService';
import './General.css';

const PayNow = () => {
  const theme = useTheme();
  const location = useLocation(); // Use location to get passed state
  const navigate = useNavigate();
  
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  
  // Retrieve totalAmount from location state and ensure it's a string
  const totalAmount = (location.state?.totalAmount || 0).toString(); 

  const handlePayment = async (e) => {
    e.preventDefault();

    try {
      const user = JSON.parse(localStorage.getItem('user')); // Get user from localStorage
      const userId = user?.id; // Extract userId
      
      const orderData = {
        userId: userId,
        orderDate: new Date().toISOString(), // Current date
        totalAmount: totalAmount, // Use the total amount from location state
        paymentStatus: "Paid" // Replace with actual payment status
      };

      await postOrder(orderData); // Call postOrder service
      alert('התשלום התקבל בהצלחה הזמנתך התקבלה.');
      navigate('/'); // Navigate after successful payment
    } catch (error) {
      console.error('Payment error:', error);
      alert('קיימת שגיאה, אנא נסה שוב.');
    }
  };

  return (
    <>
      <video autoPlay loop muted className="cart-video">
        <source src="/assets/vid.mp4" type="video/mp4" />
      </video>
      <Grid container spacing={2} 
         sx={{
            my: 4,
            backgroundColor: 'rgba(255, 238, 232, 0.5)', direction: 'rtl'
          }}>
        <Grid item xs={12}>
          <Typography variant="h2">פרטי תשלום</Typography>
          <Typography variant="h6">Total Amount: ₪{totalAmount}</Typography> {/* Display total amount */}
        </Grid>
        {/* Other payment fields can be added here */}
        <Grid item xs={12}>
          <Button variant="contained" onClick={() => navigate('/Order')}
                  style={{ backgroundColor: '#FFEEE8', color: 'black' }}>
            חזרה
          </Button>
          <Button variant="contained" type="submit" onClick={handlePayment}
                  style={{ backgroundColor: '#ff5722', color: 'black' }}>
            שלם עכשיו
          </Button>
        </Grid>
      </Grid>
    </>
  );
};

export default PayNow;
