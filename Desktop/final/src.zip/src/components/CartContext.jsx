import React, { createContext, useState } from "react";
import './General.css';

const CartContext = createContext();

const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState([]);

  const addToCart = (product, quantity) => {
    console.log('addToCart: ', product, "/nq:   ", quantity); // Placeholder action
    setCartItems([...cartItems, { product, quantity }]);
  };

  // const removeFromCart = (item) => {
  //   setCartItems(cartItems.filter((cartItem) => cartItem.product.id !== item.product.id));
  // };
  const removeFromCart = (item) => {
    setCartItems(cartItems.filter((cartItem) => {
      const stringifiedItem = JSON.stringify(item);
      const stringifiedCartItem = JSON.stringify(cartItem);
      return stringifiedItem !== stringifiedCartItem;
    }));
  };
  
  const updateProductQuant = (id, newQty) => {
    dispatchEvent({ type: 'UPDATE_QUANTITY', payload: { id, quantity: newQty } });
  };

  const calculateTotal = () => {
    return cartItems.reduce((total, item) => total + item.product.price * item.quantity, 0);
  };

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, calculateTotal, updateProductQuant }}>
      {children}
    </CartContext.Provider>
  );
};

export { CartContext, CartProvider };