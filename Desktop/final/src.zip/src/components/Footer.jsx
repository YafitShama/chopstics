import React from 'react';
import { styled } from '@mui/material/styles';
import PhoneIcon from '@mui/icons-material/Phone';
import EmailIcon from '@mui/icons-material/Email';
import PlaceIcon from '@mui/icons-material/Place';
import Instagram from '@mui/icons-material/Instagram';
import ListItemText from '@mui/material/ListItemText';
import Link from '@mui/material/Link';
import './General.css';

// Styled components
const FooterContainer = styled('footer')(({ theme }) => ({
  backgroundColor: '#ff5722',
  color: '#fff',
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  position: 'fixed',
  bottom: 0,
  width: '100%',
  minHeight: '50px',
  padding: theme.spacing(2),
}));

const DetailsContainer = styled('div')({
  display: 'flex',
  flexWrap: 'wrap',
});

const ListItemStyled = styled(ListItemText)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  marginRight: theme.spacing(4),
  textDecoration: 'none',
  color: 'black',
}));

const IconLink = styled('span')(({ theme }) => ({
  color: 'black',
  marginRight: theme.spacing(1),
}));

const AddressText = styled('span')({
  whiteSpace: 'nowrap',
  overflow: 'hidden',
  textOverflow: 'ellipsis',
});

const Footer = () => {
  const handleLinkClick = (url) => {
    window.open(url, '_blank'); // Open links in a new tab
  };

  return (
    <FooterContainer>
      <DetailsContainer>
        <Link href="tel:+972535302367" underline="none" onClick={() => handleLinkClick('tel:+972535302367')}>
          <PhoneIcon component={IconLink} />
          <ListItemStyled primary="Phone: +972 (53) 53-02367" />
        </Link>
        <Link href="mailto:chopsticks@gnail.com" underline="none" onClick={() => handleLinkClick('mailto:chopsticks@gnail.com')}>
          <EmailIcon component={IconLink} />
          <ListItemStyled primary="Email: chopsticks@gnail.com" />
        </Link>
        <Link href="https://www.google.com/maps/place/רחוב+תלמוד+בבלי+12,+בית+שמש,+ישראל" underline="none" onClick={() => handleLinkClick('https://www.google.com/maps/place/רחוב+תלמוד+בבלי+12,+בית+שמש,+ישראל')}>
          <PlaceIcon component={IconLink} />
          <ListItemStyled>
            <span>Address: </span>
            <span>
              <AddressText>רחוב תלמוד בבלי 12 בית שמש, ישראל</AddressText>
            </span>
          </ListItemStyled>
        </Link>
        <Link href="https://www.instagram.com/yafitshama_/" underline="none" onClick={() => handleLinkClick('https://www.instagram.com/yafitshama_/')}>
          <Instagram component={IconLink} />
          <ListItemStyled primary="Instagram: _yafitshama" />
        </Link>
      </DetailsContainer>
    </FooterContainer>
  );
};

export default Footer;
