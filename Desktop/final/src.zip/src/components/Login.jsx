import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TextField, Button, Box, Typography, Paper, Container, Grid } from '@mui/material';
import { loginUser } from '../servises/UserService'; // Adjust your service path

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    const credentials = { username, password }; // Ensure correct field names

    try {
      const response = await loginUser(credentials);
      console.log('User logged in:', response);
      
      // Save both ID and username to local storage
      localStorage.setItem('user', JSON.stringify({ id: response.id, username: response.username }));
      
      navigate('/User'); // Redirect after successful login
    } catch (err) {
      setError('Login failed: ' + (err.response?.data?.message || err.message)); // Improved error message
      console.error(err);
    }
  };

  const handleSignupRedirect = () => {
    navigate('/Register'); // Redirect to the signup/register page
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', position: 'relative', overflow: 'hidden' }}>
      <video autoPlay loop muted style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: -1 }}>
        <source src="/assets/vid4.mp4" type="video/mp4" />
      </video>
      <Container>
        <Grid container justifyContent="center" alignItems="center">
          <Grid item xs={12} sm={8} md={6}>
            <Paper elevation={3} sx={{ padding: 4, maxWidth: 400, backgroundColor: 'rgba(255, 238, 232, 0.7)', borderRadius: 2, boxShadow: 3 }}>
              <Typography variant="h4" gutterBottom align="center">Login</Typography>
              <form onSubmit={handleLogin} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <TextField label="Username" variant="outlined" value={username} onChange={(e) => setUsername(e.target.value)} required fullWidth />
                <TextField label="Password" variant="outlined" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required fullWidth />
                <Button type="submit" variant="contained" sx={{ backgroundColor: '#ff5722', color: 'black', '&:hover': { backgroundColor: '#e64a19' }}} fullWidth>Login</Button>
              </form>

              <Box mt={4} textAlign="center">
                <Typography variant="body1">Not registered yet?{' '}
                  <span onClick={handleSignupRedirect} style={{ cursor: 'pointer', color: '#ff5722', textDecoration: 'underline' }}>Sign up!</span>
                </Typography>
              </Box>
              {error && <Typography color="error">{error}</Typography>}
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}

export default Login;
