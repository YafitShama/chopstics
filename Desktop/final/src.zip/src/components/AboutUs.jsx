
import React from 'react';
import { Typography, Box, Grid, useTheme } from '@mui/material';
import './General.css';

const AboutUs = () => {
  const theme = useTheme();

  return (
    <div>
      <video autoPlay loop muted className="cart-video">
        <source src="/assets/vid5.mp4" type="video/mp4" />
      </video>

      <Box
        sx={{
          my: 4,
          backgroundColor: 'rgba(255, 238, 232, 0.5)', // Set background color
        }}
      >
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Typography
              dir="rtl"
              variant="h4"
              sx={{ fontWeight: 'bold', textAlign: 'center' }}
            >
            הסיפור שלנו
            </Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography variant="body1" sx={{ fontSize: theme.typography.h6.fontSize, mr: theme.spacing(4) }}>
              <p dir="rtl" style={{ textAlign: 'justify' }}>
                נעים מאוד - CHOPSTICKS – ווק אנד סושי{' '}
                <br />
                <br />
                כמו כל רשת, התחלנו בקטן. פתחנו את הסניף הראשון שלנו בירושלים, אי-שם בשנת 2004,{' '}
                <br />
                במטרה להביא את המטבח האסייתי המהיר והכשר אל קדמת הבמה.
                <br/> היום, עם 16 סניפים ברחבי הארץ ועוד מסעדות חדשות אשר עושות את דרכן לפתיחה, אנחנו יכולים להגיד שאנחנו בדרך הנכונה.{' '}
                <br />
                <br />
                רשת מסעדות כשרה על טהרת התפריט האסייתי – יפני-סיני-תאילנדי – עם השפעות ממטבחים נוספים מהמזרח הרחוק.
                <br/> יותר מ-80 מנות שעושות כבוד למקור, מחומרי הגלם היקרים והאיכותיים ביותר בייבוא מיוחד ובהכנה במקום מהנודלס ועד הרטבים המיוחדים.{' '}
                <br />
                וכן, הכול טרי. תמיד.{' '}
                <br />
                <br />
                סיירת הסושימנים וצוות הטבחים שלנו מחכים להזמנה שלכם מהמטבח לשולחן,{' '}
                <br />
                עם שליח לבית ולמשרד או באיסוף עצמי.{' '}
                <br />
                האתר והאפליקציה שלנו שם בדיוק בשביל זה, איך שנוח לכם.{' '}
                <br />
                המנות ימצאו את דרכן אליכם.
              </p>
            </Typography>
          </Grid>
        </Grid>
      </Box>
    </div>
  );
};

export default AboutUs;
