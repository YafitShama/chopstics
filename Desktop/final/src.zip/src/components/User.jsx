import React, { useState, useEffect } from 'react';
import { TextField, Button, Typography, Paper, Container, Grid, List, ListItem, ListItemText } from '@mui/material';
import { updateUser, getUserById } from '../servises/UserService'; // Adjusted imports
import { useNavigate } from 'react-router-dom';
import { getOrdersByUserId, deleteOrder } from '../servises/OrderService'; // Import deleteOrder

function User() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
          const userData = await getUserById(user.id);
          setUsername(userData.username);
          setEmail(userData.email);
          const userOrders = await getOrdersByUserId(user.id);
          setOrders(userOrders);
        }
      } catch (err) {
        console.error('Failed to fetch user data', err);
      }
    };

    fetchUserData();
  }, []);

  const handleUpdate = async (e) => {
    e.preventDefault();
    const user = JSON.parse(localStorage.getItem('user'));
    const updatedUser = { id: user.id, username, email, password };

    try {
      const response = await updateUser(updatedUser);
      console.log('User updated:', response);
      navigate('/');
    } catch (err) {
      setError('Update failed');
      console.error(err);
    }
  };

  const handleDeleteOrder = async (orderId) => {
    try {
      await deleteOrder(orderId);
      setOrders((prevOrders) => prevOrders.filter(order => order.id !== orderId)); // Remove deleted order from state
      alert('Order deleted successfully');
    } catch (err) {
      console.error('Failed to delete order', err);
      alert('Failed to delete order');
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh', position: 'relative', overflow: 'hidden' }}>
      <video autoPlay loop muted style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', objectFit: 'cover', zIndex: -1 }}>
        <source src="/assets/vid8.mp4" type="video/mp4" />
      </video>
      <Container>
        <Grid container justifyContent="center" alignItems="center">
          <Grid item xs={12} sm={8} md={6}>
            <Paper elevation={3} sx={{ padding: 4, maxWidth: 400, backgroundColor: 'rgba(255, 238, 232, 0.7)', borderRadius: 2, boxShadow: 3 }}>
              <Typography variant="h4" gutterBottom align="center">Update Details</Typography>
              <form onSubmit={handleUpdate} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                <TextField label="Username" variant="outlined" value={username} onChange={(e) => setUsername(e.target.value)} required fullWidth />
                <TextField label="Email" variant="outlined" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required fullWidth />
                <TextField label="Password" variant="outlined" type="password" value={password} onChange={(e) => setPassword(e.target.value)} fullWidth />
                <Button type="submit" variant="contained" sx={{ backgroundColor: '#ff5722', color: 'black', '&:hover': { backgroundColor: '#e64a19' }}} fullWidth>Update</Button>
              </form>
              {error && <Typography color="error">{error}</Typography>}
            </Paper>
          </Grid>
        </Grid>

        {/* Section for displaying user orders */}
        <Grid container justifyContent="center" alignItems="center" mt={4}>
          <Grid item xs={12} sm={8} md={6}>
            <Paper elevation={3} sx={{ padding: 4, maxWidth: 400, backgroundColor: 'rgba(255, 238, 232, 0.7)', borderRadius: 2, boxShadow: 3 }}>
              <Typography variant="h5" gutterBottom>Order History</Typography>
              <List>
                {orders.length > 0 ? (
                  orders.map((order) => (
                    <ListItem key={order.id}>
                      <ListItemText 
                        primary={`Order #${order.id}`} 
                        secondary={`Total: $${order.totalAmount} | Date: ${new Date(order.orderDate).toLocaleDateString()}`} 
                      />
                      <Button variant="outlined" color="error" onClick={() => handleDeleteOrder(order.id)}>
                        Delete
                      </Button>
                    </ListItem>
                  ))
                ) : (
                  <Typography variant="body2">No orders found</Typography>
                )}
              </List>
            </Paper>
          </Grid>
        </Grid>
      </Container>
    </div>
  );
}

export default User;
