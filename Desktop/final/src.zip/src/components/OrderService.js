import axios from 'axios';

// Base URL for your API
const API_URL = 'http://localhost:5000/api/order'; // Replace with your actual API URL

// Create a new order
export const createOrder = async (orderData) => {
  try {
    const response = await axios.post(`${API_URL}`, orderData);
    return response.data;
  } catch (error) {
    console.error('Error creating order:', error);
    throw error;
  }
};

