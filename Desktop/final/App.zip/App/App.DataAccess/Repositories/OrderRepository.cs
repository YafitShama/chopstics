﻿using App.DataAccess.DataContext;
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.DataAccess.Repositories
{
    public class OrderRepository : IOrderRepository
    {
        private MyShopContext _context;
        public OrderRepository(MyShopContext context)
        {
            _context = context;
        }

        public List<Order> GetAllOrders()
        {
            return _context.Orders.ToList();
        }

        public Order GetOrderrById(Guid id)
        {
            return _context.Orders.SingleOrDefault(o => o.Id == id);
        }

      

        public List<Order> GetOrdersByUserId(Guid userId)
        {
            return _context.Orders.Where(o => o.UserId != null && o.UserId == userId.ToString()).ToList();
        }


        public Order CreateOrder(Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
            return order;
        }

        public Order UpdateOrder(Order order)
        {
            _context.Orders.Entry(order).State = EntityState.Modified;
            _context.SaveChanges();
            return order;
        }

        public void Deleteorder(Guid id)
        {
            Order deleteOrder = _context.Orders.SingleOrDefault(o => o.Id == id);
            _context.Orders.Remove(deleteOrder);
            _context.SaveChanges();

        }
    }
}
