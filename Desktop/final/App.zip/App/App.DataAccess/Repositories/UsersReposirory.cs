﻿//using App.DataAccess.DataContext;
//using App.DataAccess.Entities;
//using App.DataAccess.Interfaces;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace App.DataAccess.Repositories
//{
//    public class UsersReposirory : IUsersReposirory
//    {
//        private MyShopContext db;
//        public UsersReposirory(MyShopContext shopDbontext)
//        {
//            db = shopDbontext;
//        }

//        public List<User> GetUsers()
//        {
//            return db.Users.ToList();
//        }

//        public async Task<User> CreateUser(User user)
//        {
//            try
//            {
//                db.Users.AddAsync(user);
//                db.SaveChangesAsync();
//                return user;
//            }
//            catch (Exception)
//            {

//                throw;
//            }

//        }

//        public User UpdateUser(User user)
//        {
//            db.Users.Entry(user).State = EntityState.Modified;
//            db.SaveChanges();
//            return user;
//        }

//        public Task DeleteUser(Guid userId)
//        {
//            User userToDelete = null; /*db.Users.SingleOrDefault(u => u== userId);*/
//            db.Users.Remove(userToDelete);
//            db.SaveChangesAsync();
//            return null;
//        }
//    }
//}


using App.DataAccess.DataContext;
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.DataAccess.Repositories
{
    public class UsersRepository : IUsersRepository
    {
        private MyShopContext _context;
        public UsersRepository(MyShopContext context)
        {
            _context = context;
        }

        public List<User> GetAllUsers()
        {
            return _context.Users.ToList();
        }

        public User GetUserById(Guid id)
        {
            return _context.Users.SingleOrDefault(u => u.Id == id);
        }

        public User CreateUser(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
            return user;
        }

        public User UpdateUser(User user)
        {
            _context.Users.Entry(user).State = EntityState.Modified;
            _context.SaveChanges();
            return user;
        }

        public void DeleteUser(Guid id)
        {
            User deleteUser = _context.Users.SingleOrDefault(u => u.Id == id);
            _context.Users.Remove(deleteUser);
            _context.SaveChanges();

        }

        public User GetUserByUsernameAndPassword(string username, string password)
        {
            // Here you should hash the password and compare it with the hashed password in the database
            return _context.Users.SingleOrDefault(u => u.Username == username && u.PasswordHash == password);
        }


    }

  

}








