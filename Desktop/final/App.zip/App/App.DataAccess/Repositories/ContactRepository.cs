﻿//using App.DataAccess.DataContext;
//using App.DataAccess.Entities;
//using App.DataAccess.Interfaces;
//using Microsoft.EntityFrameworkCore;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace App.DataAccess.Repositories
//{
//    public class ContactRepository : IContactRepository
//    {
//        private readonly MyShopContext _context;

//        public ContactRepository(MyShopContext shopDbContext)
//        {
//            _context = shopDbContext;
//        }

//        public List<Contact> GetContact()
//        {
//            return _context.Contacts.ToList();
//        }

//        public async Task<Contact> CreateContact(Contact contact)
//        {
//            try
//            {
//                await _context.Contacts.AddAsync(contact); // Added 'await' for asynchronous operation
//                await _context.SaveChangesAsync(); // Added 'await' to save changes asynchronously
//                return contact;
//            }
//            catch (Exception)
//            {
//                throw; // Consider logging the exception in a real-world scenario
//            }
//        }

//        public async Task<Contact> UpdateContact(Contact contact)
//        {
//            _context.Contacts.Entry(contact).State = EntityState.Modified; // Corrected from Orders to Contacts
//            await _context.SaveChangesAsync(); // Added 'await' to save changes asynchronously
//            return contact;
//        }

//        public async Task DeleteContact(Guid contactId)
//        {
//            var contactToDelete = await _context.Contacts.FindAsync(contactId); // Find the contact by ID
//            if (contactToDelete != null)
//            {
//                _context.Contacts.Remove(contactToDelete);
//                await _context.SaveChangesAsync(); // Added 'await' to save changes asynchronously
//            }
//        }
//    }
//}
