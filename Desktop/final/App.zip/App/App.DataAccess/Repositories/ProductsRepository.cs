﻿using App.DataAccess.DataContext;
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace App.DataAccess.Repositories
{
    public class ProductRepository : IProductsRepository
    {
        private readonly MyShopContext _context;

        public ProductRepository(MyShopContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            return  await _context.Product.ToListAsync(); // Returns all products
        }

    }
}
