﻿using App.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace App.DataAccess.DataContext;

public partial class MyShopContext : DbContext
{
    public MyShopContext()
    {
    }

    public MyShopContext(DbContextOptions<MyShopContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Order> Orders { get; set; }
    public virtual DbSet<Product> Product { get; set; }
    public virtual DbSet<User> Users { get; set; }


    //public virtual DbSet<Contact> Contacts { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {

        //modelBuilder.Entity<Order>(entity =>
        //{
        //    entity.HasKey(e => e.Id).HasName("PK__Orders__3214EC07D930DC63");

        //    entity.Property(e => e.OrderDate).HasColumnType("datetime");
        //    entity.Property(e => e.TotalSum).HasColumnType("decimal(18, 2)");

        //    entity.HasOne(d => d.User).WithMany(p => p.Orders)
        //        .HasForeignKey(d => d.UserId)
        //        .OnDelete(DeleteBehavior.ClientSetNull)
        //        .HasConstraintName("FK__Orders__UserId__3B75D760");
        //});

        modelBuilder.Entity<Order>(entity =>
        {
            entity.ToTable("Orders");
           

            entity.Property(e => e.Id).ValueGeneratedNever().HasColumnName("id");
            entity.Property(e => e.OrderDate).HasColumnType("datetime").HasColumnName("orderDate");
            entity.Property(e => e.PaymentStatus).HasMaxLength(10).IsFixedLength().HasColumnName("paymentStatus");
            entity.Property(e => e.TotalAmount).HasMaxLength(255).IsFixedLength().HasColumnName("totalAmount");
            entity.Property(e => e.UserId).HasMaxLength(10).IsFixedLength().HasColumnName("userId");
        });
      
            modelBuilder.Entity<Product>(entity =>
            {
                entity.ToTable("Product");

                // Define the primary key
                entity.HasKey(e => e.Id); // Ensure to define the primary key

                entity.Property(e => e.Id) // Assuming you have an Id property as primary key
                      .ValueGeneratedOnAdd() // Optional: if you want it to auto-increment
                      .HasColumnName("Id");


                entity.Property(e => e.Name).HasMaxLength(255).HasColumnName("Name");
            entity.Property(e => e.Description).HasMaxLength(8000).HasColumnName("Description");
            entity.Property(e => e.Price).HasMaxLength(10).IsFixedLength().HasColumnName("Price");
            entity.Property(e => e.Img).HasMaxLength(255).IsFixedLength().HasColumnName("Img");
        });


        //modelBuilder.Entity<User>(entity =>
        //{
        //    entity.HasKey(e => e.Id).HasName("PK__Users__3214EC0720E43C7C");
        //    entity.Property(e => e.Mail).HasMaxLength(100);
        //    entity.Property(e => e.Password).HasMaxLength(255);
        //    entity.Property(e => e.Username).HasMaxLength(50);
        //});
        modelBuilder.Entity<User>(entity =>
        {
            entity.Property(e => e.Id).ValueGeneratedNever().HasColumnName("id");
            entity.Property(e => e.Email).HasMaxLength(10).IsFixedLength();
            entity.Property(e => e.PasswordHash).HasMaxLength(10).IsFixedLength();
            entity.Property(e => e.ReceiveUpdates).HasMaxLength(10).IsFixedLength().HasColumnName("receiveUpdates");
            entity.Property(e => e.Username).HasMaxLength(10).IsFixedLength();
        });

        //modelBuilder.Entity<Contact>(entity =>
        //{
        //    entity.HasKey(e => e.Id).HasName("PK__Contact__3214EC0720E43C7C");

        //    entity.Property(e => e.Name).HasMaxLength(100);
        //    entity.Property(e => e.Mail).HasMaxLength(255);
        //    entity.Property(e => e.Message).HasMaxLength(50);
        //});

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
