﻿using App.DataAccess.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace App.DataAccess.Interfaces
{
    public interface IProductsRepository
    {
        Task<IEnumerable<Product>> GetAllProductsAsync();
    }
}
