﻿using App.DataAccess.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.DataAccess.Interfaces
{
    public interface IOrderRepository
    {
        public List<Order> GetOrdersByUserId(Guid userId);
        public List<Order> GetAllOrders();
        public Order GetOrderrById(Guid id);
        public Order CreateOrder(Order order);
        public Order UpdateOrder(Order order);
        public void Deleteorder(Guid id);
    }
}
