﻿//using App.DataAccess.Entities;
//using System;
//using System.Collections.Generic;
//using System.Threading.Tasks;

//namespace App.DataAccess.Interfaces
//{
//    public interface IContactRepository
//    {
//        Task<Contact> CreateContact(Contact contact); // Correct the parameter type to Contact
//        Task DeleteContact(Guid contactId); // No changes needed
//        List<Contact> GetContact(); // Ensure this returns List<Contact>
//        Task<Contact> UpdateContact(Contact contact); // Correct the parameter type to Contact
//    }
//}
