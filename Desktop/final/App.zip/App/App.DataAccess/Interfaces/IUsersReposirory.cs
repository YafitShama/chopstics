﻿//using App.DataAccess.Entities;

//namespace App.DataAccess.Interfaces
//{
//    public interface IUsersReposirory
//    {
//        Task<User> CreateUser(User user);
//        Task DeleteUser(Guid userId);
//        List<User> GetUsers();
//        User UpdateUser(User user);
//    }
//}
using App.DataAccess.Entities;

namespace App.DataAccess.Interfaces
{
    public interface IUsersRepository
    {
        List<User> GetAllUsers();
        User GetUserById(Guid id);
        User CreateUser(User user);
        User UpdateUser(User user);
        void DeleteUser(Guid id);
        public User GetUserByUsernameAndPassword(string username, string password);
    }
}

