﻿namespace App.DataAccess.Entities
{
    public class Product
    {
        public int Id { get; set; }  // Assuming you have a primary key Id column
        public string ? Name { get; set; }
        public string ? Description { get; set; }
        public decimal ? Price { get; set; }
        public string ? Img { get; set; }  // Assuming this is a URL or file path
    }
}
