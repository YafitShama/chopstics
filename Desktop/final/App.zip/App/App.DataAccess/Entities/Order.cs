﻿using System;
using System.Collections.Generic;

namespace App.DataAccess.Entities;

public partial class Order
{
    public Guid Id { get; set; }

    public string? UserId { get; set; }

    public DateTime? OrderDate { get; set; }

    public string? TotalAmount { get; set; }

    public string? PaymentStatus { get; set; }
}
