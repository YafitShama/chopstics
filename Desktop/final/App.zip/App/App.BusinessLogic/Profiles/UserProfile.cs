﻿using AutoMapper;
using App.DTO.Models;
using App.DataAccess.Entities;

namespace App.BusinessLogic.Profiles
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<UserDTO, User>().ReverseMap();

            CreateMap<UserDTO, UserDTO>().ReverseMap();

        }
    }
}
