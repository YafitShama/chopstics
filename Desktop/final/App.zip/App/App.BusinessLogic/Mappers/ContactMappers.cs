﻿//using App.DataAccess.Entities;
//using App.DTO.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace App.BusinessLogic.Mappers
//{
//    internal static class ContactMappers
//    {
//        internal static Contact Map(ContactDTO contact)
//        {
//            return new Contact
//            {
//                //UserId = user.UserId,
//                //Name = user.Name,
//                //LastName = user.LastName
//            };
//        }

//        internal static ContactDTO Map(Contact contact)
//        {
//            return new ContactDTO
//            {
//                //UserId = user.UserId,
//                //Name = user.Name,
//                //LastName = user.LastName
//            };
//        }
//    }
//}
