﻿using App.DataAccess.Entities;
using App.DTO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.BusinessLogic.Mappers
{
    internal static class UserMappers
    {
        internal static User Map(UserDTO user)
        {
            return new User
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email
            };
        }

        internal static UserDTO Map(User user)
        {
            return new UserDTO
            {
                Id = user.Id,
                Username = user.Username,
                Email = user.Email
            };
        }
    }
}
