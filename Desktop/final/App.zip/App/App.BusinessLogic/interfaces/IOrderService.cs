﻿using App.DTO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.BusinessLogic.interfaces
{
    public interface IOrderService
    {
        public List<OrderDTO> GetAllOrders();
        public OrderDTO GetOrderById(Guid id);
        public List<OrderDTO> GetOrdersByUserId(Guid userId);
        public OrderDTO CreateOrder(OrderDTO order);
        public OrderDTO UpdateOrder(OrderDTO order);
        public void DeleteOrder(Guid id);
    }
}
