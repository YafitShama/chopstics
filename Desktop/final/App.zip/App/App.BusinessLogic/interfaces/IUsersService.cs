﻿//using App.DataAccess.Entities;
//using App.DTO.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace App.BusinessLogic.Interfaces
//{
//    public interface IUsersService
//    {
//        public List<UserDTO> GetUsers();
//        public UserDTO CreateUser(UserDTO user);
//        public UserDTO UpdateUser(UserDTO user);
//        public void DeleteUser(Guid userId);
//    }
//}

using App.DTO.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.BusinessLogic.Interfaces
{
    public interface IUsersService
    {
        public List<UserDTO> GetAllUsers();
        public UserDTO GetUserById(Guid id);
        public UserDTO CreateUser(UserDTO user);
        public UserDTO UpdateUser(UserDTO user);
        public void DeleteUser(Guid id);


        public UserDTO Login(LoginRequestDTO loginRequest);
    }
}
