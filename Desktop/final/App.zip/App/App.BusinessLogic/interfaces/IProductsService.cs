﻿using App.DataAccess.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace App.Business.Interfaces
{
    public interface IProductService
    {
        Task<IEnumerable<Product>> GetAllProductsAsync();
    }
}
