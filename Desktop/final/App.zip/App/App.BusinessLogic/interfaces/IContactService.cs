﻿//using App.DTO.Models;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace App.BusinessLogic.interfaces
//{
//    public interface IContactService
//    {
//        public List<ContactDTO> GetContacts();
//        public ContactDTO CreateContact(ContactDTO contact);
//        public ContactDTO UpdateContact(ContactDTO contact);
//        public void DeleteContact(Guid contactId);
//    }
//}

