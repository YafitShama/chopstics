﻿using App.DataAccess.Interfaces;
using App.Business.Interfaces;
using App.DataAccess.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace App.Business.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductsRepository _productsRepository;

        public ProductService(IProductsRepository productsRepository)
        {
            _productsRepository = productsRepository;
        }

        public async Task<IEnumerable<Product>> GetAllProductsAsync()
        {
            return await _productsRepository.GetAllProductsAsync();
        }
    }
}
