﻿using App.BusinessLogic.interfaces;
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;
using App.DataAccess.Repositories;
using App.DTO.Models;
using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.BusinessLogic.Services
{
    public class OrderService : IOrderService
    {
        private IOrderRepository _orderRepository;
        private IMapper _mapper;

        public OrderService(IOrderRepository orderRepository, IMapper mapper)
        {
            _orderRepository = orderRepository;
            _mapper = mapper;
        }

        public List<OrderDTO> GetAllOrders()
        {
            List<Order> listOrder = _orderRepository.GetAllOrders();
            return _mapper.Map<List<OrderDTO>>(listOrder);
        }

        public OrderDTO GetOrderById(Guid id)
        {
            return _mapper.Map<OrderDTO>(_orderRepository.GetOrderrById(id));
        }

        public OrderDTO CreateOrder(OrderDTO order)

        

        {
            order.Id = Guid.NewGuid();
            Order createOrder = _orderRepository.CreateOrder(_mapper.Map<Order>(order));
            return _mapper.Map<OrderDTO>(createOrder);
        }

        public OrderDTO UpdateOrder(OrderDTO order)
        {
            Order orderUpdat = _orderRepository.UpdateOrder(_mapper.Map<Order>(order));
            return _mapper.Map<OrderDTO>(orderUpdat);
        }

        public List<OrderDTO> GetOrdersByUserId(Guid userId)
        {
            List<Order> orders = _orderRepository.GetOrdersByUserId(userId);
            return _mapper.Map<List<OrderDTO>>(orders);
        }

        public void DeleteOrder(Guid id)
        {
            _orderRepository.Deleteorder(id);
        }
    }
}
