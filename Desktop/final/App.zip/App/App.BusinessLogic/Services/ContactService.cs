﻿//using App.BusinessLogic.interfaces;
//using App.BusinessLogic.Interfaces;
//using App.DataAccess.Entities;
//using App.DataAccess.Interfaces;
//using App.DTO.Models;
//using AutoMapper;
//using System;
//using System.Collections.Generic;
//using System.Threading.Tasks;

//namespace App.BusinessLogic.Services
//{
//    public class ContactService : IContactService
//    {
//        private readonly IContactRepository _contactRepository;
//        private readonly IMapper _mapper;

//        public ContactService(IContactRepository contactRepository, IMapper mapper)
//        {
//            _contactRepository = contactRepository;
//            _mapper = mapper;
//        }

//        public List<ContactDTO> GetContact()
//        {
//            // Fetch contacts from repository
//            List<Contact> contactList = _contactRepository.GetContact(); // Should fetch Contact entities

//            // Map the list of Contact entities to a list of ContactDTOs
//            return _mapper.Map<List<ContactDTO>>(contactList);
//        }

//        public ContactDTO CreateContact(ContactDTO contact)
//        {
//            try
//            {
//                contact.ContactId = Guid.NewGuid(); // Assign a new GUID

//                // Map ContactDTO to Contact entity
//                var contactEntity = _mapper.Map<Contact>(contact);

//                // Call repository to create a new contact
//                var createdContactEntity = _contactRepository.CreateContact(contactEntity);

//                // Map the created Contact entity back to a ContactDTO
//                return _mapper.Map<ContactDTO>(createdContactEntity);
//            }
//            catch (Exception)
//            {
//                // Log exception here
//                throw;
//            }
//        }

//        public ContactDTO UpdateContact(ContactDTO contact)
//        {
//            // Map ContactDTO to Contact entity
//            var contactEntity = _mapper.Map<Contact>(contact);

//            // Call repository to update the contact
//            var updatedContactEntity = _contactRepository.UpdateContact(contactEntity);

//            // Map the updated Contact entity back to a ContactDTO
//            return _mapper.Map<ContactDTO>(updatedContactEntity);
//        }

//        public void DeleteContact(Guid contactId)
//        {
//            // Call repository to delete the contact
//            _contactRepository.DeleteContact(contactId);
//        }

//        public List<ContactDTO> GetContacts()
//        {
//            throw new NotImplementedException();
//        }
//    }
//}

