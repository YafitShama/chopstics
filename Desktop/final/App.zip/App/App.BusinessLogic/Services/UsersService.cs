﻿//using App.BusinessLogic.Interfaces;
//using App.BusinessLogic.Mappers;
//using App.DataAccess.Entities;
//using App.DataAccess.Interfaces;
//using App.DTO.Models;
//using AutoMapper;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace App.BusinessLogic.Services
//{
//    public class UsersService : IUsersService
//    {
//        private IUsersReposirory users;
//        private IMapper _mapper;
//        public UsersService(IUsersReposirory usersRepository, IMapper mapper)
//        {
//            users = usersRepository;
//            _mapper = mapper;
//        }

//        public List<UserDTO> GetUsers()
//        {
//           List<User> userList =  users.GetUsers();

//            //return userList.Select(u => UserMappers.Map(u)).ToList();
//            return _mapper.Map<List<UserDTO>>(userList);
//        }

//        public UserDTO CreateUser(UserDTO user)
//        {
//            try
//            {
//             user.UserId = Guid.NewGuid();
//                //User createdUser =  users.CreateUser(UserMappers.Map(user));
//                IUsersReposirory users1 = users;
//                Task<User >createdUser = users1.CreateUser(_mapper.Map<User>(user));

//            //return  UserMappers.Map(createdUser);
//            return _mapper.Map<UserDTO>(createdUser);
//            }
//            catch (Exception)
//            {

//                throw;
//            }

//        }

//        public UserDTO UpdateUser(UserDTO user)
//        {
//            User updatedUser = users.UpdateUser(_mapper.Map<User>(user));
//            return _mapper.Map<UserDTO>(updatedUser);
//        }

//        public void DeleteUser(Guid userId)
//        {
//            users.DeleteUser(userId);
//        }
//    }
//}

using App.BusinessLogic.Interfaces;  
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;     
using App.DTO.Models;
using AutoMapper;

namespace App.BusinessLogic.Services
{
    public class UsersService : IUsersService 
    {
        private readonly IUsersRepository _userRepository;
        private readonly IMapper _mapper;

        public UsersService(IUsersRepository userRepository, IMapper mapper)
        {
            _userRepository = userRepository;
            _mapper = mapper;
        }

        public List<UserDTO> GetAllUsers()
        {
            List<User> listUsers = _userRepository.GetAllUsers();
            return _mapper.Map<List<UserDTO>>(listUsers);
        }

        public UserDTO GetUserById(Guid id)
        {
            return _mapper.Map<UserDTO>(_userRepository.GetUserById(id));
        }

        public UserDTO CreateUser(UserDTO user)
        {
            user.Id = Guid.NewGuid(); 
            User createUser = _userRepository.CreateUser(_mapper.Map<User>(user));
            return _mapper.Map<UserDTO>(createUser);
        }

        public UserDTO UpdateUser(UserDTO user)
        {
            User updatedUser = _userRepository.UpdateUser(_mapper.Map<User>(user));
            return _mapper.Map<UserDTO>(updatedUser);
        }
        public UserDTO Login(LoginRequestDTO loginRequest)
        {
            // You would typically hash the password before comparing it
            User user = _userRepository.GetUserByUsernameAndPassword(loginRequest.Username, loginRequest.Password);
            if (user != null)
            {
                return _mapper.Map<UserDTO>(user);
            }
            return null; // Return null if credentials are incorrect
        }

        public void DeleteUser(Guid id)
        {
            _userRepository.DeleteUser(id);
        }
    }
}
