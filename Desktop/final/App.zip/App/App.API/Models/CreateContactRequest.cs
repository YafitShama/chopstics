﻿//namespace App.API.Models
//{
//    public class CreateContactRequest
//    {
//        public string? Name { get; set; }

//        public string? Mail { get; set; }

//        public string? Message { get; set; }
//    }
//}

