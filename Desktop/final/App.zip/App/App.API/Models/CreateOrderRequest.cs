﻿namespace App.API.Models
{
    public class CreateOrderRequest
    {
        public string? UserId { get; set; }

        public DateTime? OrderDate { get; set; }

        public string? TotalAmount { get; set; }

        public string? PaymentStatus { get; set; }
    }
}
