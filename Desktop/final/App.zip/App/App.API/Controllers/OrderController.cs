﻿using App.API.Models;
using App.BusinessLogic.interfaces;
using App.DTO.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace App.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private IOrderService _orderService;
        private IMapper _mapper;

        public OrderController(IOrderService orderService, IMapper mapper)
        {
            _orderService = orderService;
            _mapper = mapper;
        }

        [HttpGet]
        public List<OrderDTO> GetAllOrders()
        {
            return _orderService.GetAllOrders();
        }

        [HttpGet("{id}")]
        public OrderDTO GetOrderById(Guid id)
        {
            return _orderService.GetOrderById(id);
        }

        [HttpPost]
        public OrderDTO CreateRout([FromBody] CreateOrderRequest order)
        {
            return _orderService.CreateOrder(_mapper.Map<OrderDTO>(order));
        }

        [HttpPut]
        public OrderDTO UpdateRout([FromBody] OrderDTO order)
        {
            return _orderService.UpdateOrder(order);
        }


        [HttpGet("user/{userId}")]
        public List<OrderDTO> GetOrdersByUserId(Guid userId)
        {
            return _orderService.GetOrdersByUserId(userId);
        }

        [HttpDelete("{id}")]
        public void DeleteRout(Guid id)
        {
            _orderService.DeleteOrder(id);
        }
    }
}
