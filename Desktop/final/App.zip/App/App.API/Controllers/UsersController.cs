﻿using App.API.Modles;
using App.BusinessLogic.Interfaces;
using App.DTO.Models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace App.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private IUsersService _userService;
        private IMapper _mapper;

        public UsersController(IUsersService userService, IMapper mapper)
        {
            _userService = userService;
            _mapper = mapper;
        }

        [HttpGet]
        public List<UserDTO> GetAllUsers()
        {
            return _userService.GetAllUsers();
        }

        [HttpGet("{id}")]
        public UserDTO GetUserById(Guid id)
        {
            return _userService.GetUserById(id);
        }

        [HttpPost]
        public UserDTO CreateUser([FromBody] CreateUserRequest user)
        {
            return _userService.CreateUser(_mapper.Map<UserDTO>(user));
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequestDTO loginRequest)
        {
            var user = _userService.Login(loginRequest);
            if (user != null)
            {
                return Ok(user); // Return user data or a token if you are implementing JWT
            }
            return Unauthorized("Invalid username or password");
        }

        [HttpPut]
        public UserDTO UpdateRout([FromBody] UserDTO order)
        {
            return _userService.UpdateUser(order);
        }

        [HttpDelete("{id}")]
        public void DeleteUser(Guid id)
        {
            _userService.DeleteUser(id);
        }
    }
}
