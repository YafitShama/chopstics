﻿//using App.API.Models;
//using App.BusinessLogic.interfaces;
//using App.BusinessLogic.Interfaces;
//using App.DTO.Models;
//using AutoMapper;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;

//namespace App.API.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ContactController : ControllerBase
//    {
//        private IContactService _contactService;
//        private IMapper _mapper;
//        public ContactController(IContactService contactService, IMapper mapper)
//        {
//            _contactService = contactService;
//            _mapper = mapper;
//        }

//        [HttpGet]
//        public List<ContactDTO> GetContact()
//        {
//            return _contactService.GetContacts();
//        }

//        [HttpPost]
//        public ContactDTO createContact([FromBody] CreateContactRequest contact)
//        {
//            //return _usersService.CreateUser(UserMappers.Map(user));
//            return _contactService.CreateContact(_mapper.Map<ContactDTO>(contact));
//        }

//        [HttpPut]
//        public ContactDTO UpdateContact([FromBody] ContactDTO contact)
//        {
//            return _contactService.UpdateContact(contact);
//        }

//        [HttpDelete("{contactId}")]
//        public void DeleteContact(Guid contactId)
//        {
//            _contactService.DeleteContact(contactId);
//        }

//    }
//}
