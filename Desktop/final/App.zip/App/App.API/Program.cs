using App.API.Mappers;
using App.API.Profiles;
using App.BusinessLogic.Interfaces;
using App.BusinessLogic.Profiles;
using App.BusinessLogic.Services;
using App.DataAccess.DataContext;
using App.DataAccess.Entities;
using App.DataAccess.Interfaces;
using App.DataAccess.Repositories;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using App.BusinessLogic.interfaces;
using App.Business.Interfaces;
using App.Business.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigin", policy =>
    {
        policy.WithOrigins("http://localhost:3000") // Your frontend URL
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials(); // Allow credentials if you need to send cookies or headers
    });
});

// Register AutoMapper profiles
builder.Services.AddAutoMapper(typeof(App.BusinessLogic.Profiles.UserProfile).Assembly);
builder.Services.AddAutoMapper(
    typeof(UserProfile).Assembly, // Business Logic Profile
    typeof(ClientUserProfile).Assembly, // API Profile
    typeof(OrderProfile).Assembly, // Business Logic Profile
    typeof(ClientOrderProfile).Assembly // API Profile
);

builder.Services.AddScoped<IOrderRepository, OrderRepository>();
builder.Services.AddScoped<IUsersRepository, UsersRepository>();
builder.Services.AddScoped<IProductsRepository, ProductRepository>();
builder.Services.AddScoped<IOrderService, OrderService>();
builder.Services.AddScoped<IUsersService, UsersService>();
builder.Services.AddScoped<IProductService, ProductService>();

builder.Services.AddDbContext<MyShopContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("sql"));
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseCors("AllowSpecificOrigin"); // Apply CORS policy
app.UseAuthorization();
app.MapControllers();

app.Run();
