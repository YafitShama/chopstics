﻿//using App.API.Models;
//using App.DTO.Models;
//using AutoMapper;

//namespace App.API.Profiles
//{
//    public class ContactProfile : Profile
//    {
//        public ContactProfile()
//        {
//            CreateMap<CreateContactRequest, ContactDTO>();
//        }
//    }
//}
