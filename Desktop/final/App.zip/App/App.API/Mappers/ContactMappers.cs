﻿//using App.API.Models;
//using App.DTO.Models;

//namespace App.API.Mappers
//{
//    internal static class ContactMappers
//    {
//        internal static ContactDTO Map(CreateContactRequest contact)
//        {
//            return new ContactDTO
//            {
//                Name = contact.Name, 
//                Mail = contact.Mail, 
//                Message = contact.Message 
//            };
//        }
//    }
//}
