﻿using App.API.Models;
using App.API.Modles;
using App.DataAccess.Entities;
using App.DTO.Models;

namespace App.API.Mappers
{
    internal static class UserMappers
    {
        internal static UserDTO Map(User user)
        {
            return new UserDTO
            {
                Id = new Guid(),
                Username = user.Username,
                Email = user.Email,
                PasswordHash = user.PasswordHash
            };
        }


        internal static User Map(UserDTO user)
        {
            return new User
            {
                Id = new Guid(),
                Username = user.Username,
                Email = user.Email
            };
        }
    }
}

